class Animal:
    def eat(self):
        return "eating..."

# In the animal.py file, create a class called Animal with a single method eat() that returns: "eating…".